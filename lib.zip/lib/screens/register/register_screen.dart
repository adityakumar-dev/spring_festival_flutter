import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:spring_admin/apis/local_storage.dart';
import 'package:spring_admin/screens/login/login.dart';
import 'package:spring_admin/screens/quick_register.dart';
import 'package:spring_admin/utils/constants/server_endpoints.dart';

class RegisterScreen extends StatefulWidget {
  static const String routeName = '/register';
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _idNumberController = TextEditingController();
  final TextEditingController _groupNameController = TextEditingController();
  final TextEditingController _groupCountController = TextEditingController();
  
  File? _profilePicture;
  String _selectedIdType = 'Aadhar';
  bool _isGroup = false;
  
  final List<String> _idTypes = ['Aadhar', 'PAN'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(70),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 10, 128, 120),
                Color.fromARGB(255, 5, 100, 100),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20),
            ),
          ),
          child: AppBar(
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
            ),
            backgroundColor: Colors.transparent,
            title: Text(
              "Register Your Account",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.check, color: Colors.white),
                onPressed: () async {
                  if (_nameController.text.isEmpty ||
                      _emailController.text.isEmpty ||
                      _idNumberController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Please fill all the required fields", backgroundColor: Colors.red, textColor: Colors.white);
                  } else if (_profilePicture == null) {
                    Fluttertoast.showToast(msg: "Please upload your profile picture", backgroundColor: Colors.red, textColor: Colors.white);
                  } else if (_isGroup && _groupCountController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Please enter group count", backgroundColor: Colors.red, textColor: Colors.white);
                  } else {
                    await _handleRegister();
                  }
                },
              ),
            ],
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              inputTextfield("Full Name", Icons.person_outline_rounded, _nameController, isFocused: true, readOnly: false),
              const SizedBox(height: 10),
              inputTextfield("Email", Icons.email_outlined, _emailController, readOnly: false),
              const SizedBox(height: 10),
              
              // ID Type Selection
              SizedBox(
                width: double.infinity,
                child: Text(
                  "ID Type",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              DropdownButtonFormField<String>(
                value: _selectedIdType,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.badge_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                items: _idTypes.map((String type) {
                  return DropdownMenuItem(
                    value: type,
                    child: Text(type),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedIdType = newValue!;
                  });
                },
              ),
              const SizedBox(height: 10),
              
              inputTextfield("ID Number", Icons.numbers_outlined, _idNumberController, readOnly: false),
              const SizedBox(height: 10),
              
              // Individual/Group Toggle
              SwitchListTile(
                title: Text("Register as Group"),
                value: _isGroup,
                onChanged: (bool value) {
                  setState(() {
                    _isGroup = value;
                  });
                },
              ),
              
              if (_isGroup) ...[
                const SizedBox(height: 10),
                inputTextfield("Group Name (Optional)", Icons.group_outlined, _groupNameController, readOnly: false),
                const SizedBox(height: 10),
                inputTextfield("Number of Members", Icons.people_outlined, _groupCountController, readOnly: false, isNumber: true),
              ],
              
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: Text(
                  "Profile Picture",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                onTap: () {
                  ImagePicker().pickImage(source: ImageSource.gallery).then((value) {
                    setState(() {
                      if (value != null) {
                        _profilePicture = File(value.path);
                      }
                    });
                  });
                },
                title: Text(
                  _profilePicture == null ? "Please upload your profile picture" : _profilePicture!.path.split('/').last,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                leading: _profilePicture == null 
                  ? Icon(Icons.person_outline_rounded) 
                  : Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                          image: FileImage(_profilePicture!),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget inputTextfield(String label, IconData icon, TextEditingController controller, {bool isFocused = false, bool readOnly = true, bool isPassword = false, bool isNumber = false}) {
    return TextField(
      controller: controller,
      readOnly: readOnly,
      obscureText: isPassword,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Future<void> _handleRegister() async {
    showLoadingDialog(context, "Registering...");

    final request = http.MultipartRequest('POST', Uri.parse(ServerEndpoints.registerUser()));
    request.fields['name'] = _nameController.text.trim();
    request.fields['email'] = _emailController.text.trim();
    request.fields['id_type'] = _selectedIdType.toLowerCase();
    request.fields['id'] = _idNumberController.text.trim();
    
    if (_isGroup) {
      request.fields['group_name'] = _groupNameController.text.trim();
      request.fields['count'] = _groupCountController.text.trim();
    }

    if (_profilePicture != null) {
      request.files.add(await http.MultipartFile.fromPath('image', _profilePicture!.path));
    }

    try {
      final response = await request.send();
      final responseStr = await response.stream.bytesToString();
      final data = jsonDecode(responseStr);

      if (response.statusCode == 200 && data["status"] == true) {
        Fluttertoast.showToast(msg: "Registration successful", backgroundColor: Colors.green, textColor: Colors.white);
        Navigator.pop(context);
        Navigator.pop(context);
      } else {
        Fluttertoast.showToast(msg: data["message"] ?? "Registration failed", backgroundColor: Colors.red, textColor: Colors.white);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "An error occurred: $e", backgroundColor: Colors.red, textColor: Colors.white);
    } finally {
      Navigator.pop(context);
    }
  }
}